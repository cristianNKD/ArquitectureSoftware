package test.modelo;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import modelo.AnaliticaJuego;

public class AnaliticaJuegoTest {

    @Test
    void testTiempoTranscurrido() throws InterruptedException {
        AnaliticaJuego analitica = new AnaliticaJuego();

        analitica.iniciarTiempo();
        Thread.sleep(100);
        analitica.finalizarTiempo();

        assertTrue(analitica.getTiempoTotalSegundos() >= 0);
    }

    @Test
    void testCalculoEficiencia() {
        AnaliticaJuego analitica = new AnaliticaJuego();

        double eficiencia = analitica.calcularEficiencia(5, 50);

        assertEquals(0.1, eficiencia);
    }
}
