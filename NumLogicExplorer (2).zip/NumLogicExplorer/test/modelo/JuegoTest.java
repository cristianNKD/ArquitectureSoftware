package test.modelo;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import modelo.Juego;
import modelo.NivelDificultad;

public class JuegoTest {

    @Test
    void testNumeroDentroDeRango() {
        NivelDificultad nivel = new NivelDificultad("Test", 1, 10);
        Juego juego = new Juego(nivel);

        for (int i = 1; i <= 10; i++) {
            assertTrue(juego.estaEnRango(i));
        }
    }

    @Test
    void testNumeroFueraDeRango() {
        NivelDificultad nivel = new NivelDificultad("Test", 1, 10);
        Juego juego = new Juego(nivel);

        assertFalse(juego.estaEnRango(0));
        assertFalse(juego.estaEnRango(11));
    }

    @Test
    void testIncrementoIntentos() {
        NivelDificultad nivel = new NivelDificultad("Test", 1, 10);
        Juego juego = new Juego(nivel);

        juego.validarNumero(5);
        juego.validarNumero(3);

        assertEquals(2, juego.getIntentos());
    }
}
