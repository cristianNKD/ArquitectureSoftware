package test.modelo;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import modelo.NivelDificultad;

public class NivelDificultadTest {

    @Test
    void testCreacionNivel() {
        NivelDificultad nivel = new NivelDificultad("Fácil", 1, 50);

        assertEquals("Fácil", nivel.getNombre());
        assertEquals(1, nivel.getRangoMin());
        assertEquals(50, nivel.getRangoMax());
    }
}
