package modelo;

import java.util.Random;

public class Juego {

    private int numeroSecreto;
    private int intentos;
    private NivelDificultad nivel;

    public Juego(NivelDificultad nivel) {
        this.nivel = nivel;
        this.intentos = 0;
        generarNumeroSecreto();
    }

    private void generarNumeroSecreto() {
        Random random = new Random();
        numeroSecreto = random.nextInt(
                nivel.getRangoMax() - nivel.getRangoMin() + 1
        ) + nivel.getRangoMin();
    }

    public String validarNumero(int numero) {
        intentos++;

        if (numero < numeroSecreto) {
            return "El número es mayor.";
        } else if (numero > numeroSecreto) {
            return "El número es menor.";
        } else {
            return "CORRECTO";
        }
    }

    public boolean estaEnRango(int numero) {
        return numero >= nivel.getRangoMin() && numero <= nivel.getRangoMax();
    }

    public int getIntentos() {
        return intentos;
    }

    public NivelDificultad getNivel() {
        return nivel;
    }
}
