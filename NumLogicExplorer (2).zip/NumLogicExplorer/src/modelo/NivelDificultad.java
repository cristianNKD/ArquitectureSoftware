package modelo;

public class NivelDificultad {

    private String nombre;
    private int rangoMin;
    private int rangoMax;

    public NivelDificultad(String nombre, int rangoMin, int rangoMax) {
        this.nombre = nombre;
        this.rangoMin = rangoMin;
        this.rangoMax = rangoMax;
    }

    public String getNombre() {
        return nombre;
    }

    public int getRangoMin() {
        return rangoMin;
    }

    public int getRangoMax() {
        return rangoMax;
    }
}
