package modelo;

public class AnaliticaJuego {

    private long tiempoInicio;
    private long tiempoFin;

    public void iniciarTiempo() {
        tiempoInicio = System.currentTimeMillis();
    }

    public void finalizarTiempo() {
        tiempoFin = System.currentTimeMillis();
    }

    public long getTiempoTotalSegundos() {
        return (tiempoFin - tiempoInicio) / 1000;
    }

    public double calcularEficiencia(int intentos, int rango) {
        return (double) intentos / rango;
    }
}
