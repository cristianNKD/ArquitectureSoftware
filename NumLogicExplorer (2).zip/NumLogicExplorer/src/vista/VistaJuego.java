package vista;

import java.util.Scanner;

public class VistaJuego {

    private Scanner scanner = new Scanner(System.in);

    public void mostrarMensaje(String mensaje) {
        System.out.println(mensaje);
    }

    public String leerEntrada() {
        System.out.print("> ");
        return scanner.nextLine();
    }
}
