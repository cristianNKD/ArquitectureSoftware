package controlador;

import modelo.*;
import vista.VistaJuego;

public class ControladorJuego {

    private VistaJuego vista = new VistaJuego();

    public void iniciar() {

        boolean jugarDeNuevo = true;

        while (jugarDeNuevo) {

            NivelDificultad nivel = seleccionarNivel();
            Juego juego = new Juego(nivel);
            AnaliticaJuego analitica = new AnaliticaJuego();

            analitica.iniciarTiempo();
            vista.mostrarMensaje(
                "Nivel: " + nivel.getNombre() +
                " | Rango: " + nivel.getRangoMin() +
                " - " + nivel.getRangoMax()
            );

            boolean terminado = false;

            while (!terminado) {
                vista.mostrarMensaje("Ingresa un número:");
                String entrada = vista.leerEntrada();

                try {
                    int numero = Integer.parseInt(entrada);

                    if (!juego.estaEnRango(numero)) {
                        vista.mostrarMensaje("Número fuera del rango permitido.");
                        continue;
                    }

                    String resultado = juego.validarNumero(numero);

                    if (resultado.equals("CORRECTO")) {
                        analitica.finalizarTiempo();
                        vista.mostrarMensaje("¡Correcto!");
                        vista.mostrarMensaje("Intentos: " + juego.getIntentos());
                        vista.mostrarMensaje(
                            "Tiempo total: " +
                            analitica.getTiempoTotalSegundos() + " segundos"
                        );

                        int rango = nivel.getRangoMax() - nivel.getRangoMin() + 1;
                        vista.mostrarMensaje(
                            "Eficiencia: " +
                            analitica.calcularEficiencia(juego.getIntentos(), rango)
                        );

                        terminado = true;
                    } else {
                        vista.mostrarMensaje(resultado);
                    }

                } catch (NumberFormatException e) {
                    vista.mostrarMensaje("Error: ingrese un valor numérico válido.");
                }
            }

            vista.mostrarMensaje("¿Desea jugar nuevamente? (s/n)");
            jugarDeNuevo = vista.leerEntrada().equalsIgnoreCase("s");
        }

        vista.mostrarMensaje("Gracias por jugar. Fin del programa.");
    }

    private NivelDificultad seleccionarNivel() {

        vista.mostrarMensaje("Seleccione dificultad:");
        vista.mostrarMensaje("1. Fácil (1 - 50)");
        vista.mostrarMensaje("2. Medio (1 - 100)");
        vista.mostrarMensaje("3. Difícil (1 - 200)");

        while (true) {
            String opcion = vista.leerEntrada();

            switch (opcion) {
                case "1":
                    return new NivelDificultad("Fácil", 1, 50);
                case "2":
                    return new NivelDificultad("Medio", 1, 100);
                case "3":
                    return new NivelDificultad("Difícil", 1, 200);
                default:
                    vista.mostrarMensaje("Opción inválida. Intente de nuevo.");
            }
        }
    }
}
