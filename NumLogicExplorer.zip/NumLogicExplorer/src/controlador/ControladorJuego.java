package controlador;

import modelo.Juego;
import vista.VistaJuego;

public class ControladorJuego {

    private VistaJuego vista;

    public ControladorJuego() {
        vista = new VistaJuego();
    }

    public void iniciarJuego() {
        boolean jugarDeNuevo = true;

        while (jugarDeNuevo) {
            Juego juego = new Juego();
            boolean juegoTerminado = false;

            vista.mostrarMensaje("=== Bienvenido a NumLogic Explorer ===");
            vista.mostrarMensaje("Adivina el número entre 1 y 100");

            while (!juegoTerminado) {
                String entrada = vista.leerEntrada();

                try {
                    int numero = Integer.parseInt(entrada);
                    String resultado = juego.validarNumero(numero);

                    if (resultado.equals("CORRECTO")) {
                        vista.mostrarMensaje("¡Correcto! Has adivinado el número.");
                        vista.mostrarMensaje("Intentos realizados: " + juego.getIntentos());
                        juegoTerminado = true;
                    } else {
                        vista.mostrarMensaje(resultado);
                    }

                } catch (NumberFormatException e) {
                    vista.mostrarMensaje("Error: Debes ingresar un valor numérico.");
                }
            }

            vista.mostrarMensaje("¿Desea jugar nuevamente? (s/n)");
            String respuesta = vista.leerEntrada();

            if (!respuesta.equalsIgnoreCase("s")) {
                jugarDeNuevo = false;
                vista.mostrarMensaje("Gracias por jugar. ¡Hasta pronto!");
            }
        }
    }
}
