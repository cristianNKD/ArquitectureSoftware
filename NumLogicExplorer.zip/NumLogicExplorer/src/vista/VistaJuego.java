package vista;

import java.util.Scanner;

public class VistaJuego {

    private Scanner scanner;

    public VistaJuego() {
        scanner = new Scanner(System.in);
    }

    public void mostrarMensaje(String mensaje) {
        System.out.println(mensaje);
    }

    public String leerEntrada() {
        System.out.print("Ingresa un número: ");
        return scanner.nextLine();
    }
}

