package modelo;

import java.util.Random;

public class Juego {

    private int numeroSecreto;
    private int intentos;

    public Juego() {
        generarNumeroSecreto();
        intentos = 0;
    }

    private void generarNumeroSecreto() {
        Random random = new Random();
        numeroSecreto = random.nextInt(100) + 1; // rango entre 1 a 100
    }

    public String validarNumero(int numeroIngresado) {
        intentos++;

        if (numeroIngresado < numeroSecreto) {
            return "El número es mayor.";
        } else if (numeroIngresado > numeroSecreto) {
            return "El número es menor.";
        } else {
            return "CORRECTO";
        }
    }

    public int getIntentos() {
        return intentos;
    }
}
