package domain.validator;

import domain.ExcepcionRomanoInvalido;

import java.util.Map;
import java.util.Set;

public class ValidadorSustraccion implements IValidadorRomano {

    private final Map<Character, Set<Character>> reglas = Map.of(
            'I', Set.of('V', 'X'),
            'X', Set.of('L', 'C'),
            'C', Set.of('D', 'M')
    );

    @Override
    public void validar(String romano) {
        for (int i = 0; i < romano.length() - 1; i++) {
            char actual = romano.charAt(i);
            char siguiente = romano.charAt(i + 1);

            if (valor(actual) < valor(siguiente)) {
                if (!reglas.containsKey(actual)
                        || !reglas.get(actual).contains(siguiente)) {
                    throw new ExcepcionRomanoInvalido(
                            "Sustracción inválida: " + actual + siguiente
                    );
                }
            }
        }
    }

    private int valor(char c) {
        return switch (c) {
            case 'I' -> 1;
            case 'V' -> 5;
            case 'X' -> 10;
            case 'L' -> 50;
            case 'C' -> 100;
            case 'D' -> 500;
            case 'M' -> 1000;
            default -> 0;
        };
    }
}
