package domain.validator;

import domain.ExcepcionRomanoInvalido;

public interface IValidadorRomano {
    void validar(String romano) throws ExcepcionRomanoInvalido;
}
