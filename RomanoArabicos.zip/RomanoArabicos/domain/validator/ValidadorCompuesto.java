package domain.validator;

import java.util.ArrayList;
import java.util.List;

public class ValidadorCompuesto {

    private final List<IValidadorRomano> validadores = new ArrayList<>();

    public void agregarValidador(IValidadorRomano validador) {
        validadores.add(validador);
    }

    public void validar(String romano) {
        for (IValidadorRomano v : validadores) {
            v.validar(romano);
        }
    }
}
