package domain.validator;

import domain.ExcepcionRomanoInvalido;

import java.util.Set;

public class ValidadorSimbolosPermitidos implements IValidadorRomano {

    private final Set<Character> simbolosPermitidos =
            Set.of('I', 'V', 'X', 'L', 'C', 'D', 'M');

    @Override
    public void validar(String romano) {
        for (char c : romano.toCharArray()) {
            if (!simbolosPermitidos.contains(c)) {
                throw new ExcepcionRomanoInvalido(
                        "Símbolo inválido: " + c
                );
            }
        }
    }
}
