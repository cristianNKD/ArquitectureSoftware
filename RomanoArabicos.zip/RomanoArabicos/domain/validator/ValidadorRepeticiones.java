package domain.validator;

import domain.ExcepcionRomanoInvalido;

import java.util.Set;

public class ValidadorRepeticiones implements IValidadorRomano {

    private final Set<Character> noRepetibles = Set.of('V', 'L', 'D');

    @Override
    public void validar(String romano) {
        int contador = 1;

        for (int i = 1; i < romano.length(); i++) {
            char actual = romano.charAt(i);
            char anterior = romano.charAt(i - 1);

            if (actual == anterior) {
                contador++;

                if (noRepetibles.contains(actual)) {
                    throw new ExcepcionRomanoInvalido(
                            "El símbolo " + actual + " no puede repetirse"
                    );
                }

                if (contador > 3) {
                    throw new ExcepcionRomanoInvalido(
                            "El símbolo " + actual + " se repite más de 3 veces"
                    );
                }
            } else {
                contador = 1;
            }
        }
    }
}
