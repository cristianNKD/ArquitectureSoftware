package domain;

public class ExcepcionRomanoInvalido extends RuntimeException {

    public ExcepcionRomanoInvalido(String mensaje) {
        super(mensaje);
    }
}
