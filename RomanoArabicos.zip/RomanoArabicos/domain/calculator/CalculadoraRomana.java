package domain.calculator;

import java.util.Map;

public class CalculadoraRomana {

    private final Map<Character, Integer> valores = Map.of(
            'I', 1,
            'V', 5,
            'X', 10,
            'L', 50,
            'C', 100,
            'D', 500,
            'M', 1000
    );

    public int aDecimal(String romano) {
        int total = 0;

        for (int i = 0; i < romano.length(); i++) {
            int actual = valores.get(romano.charAt(i));
            int siguiente = (i + 1 < romano.length())
                    ? valores.get(romano.charAt(i + 1))
                    : 0;

            if (actual < siguiente) {
                total -= actual;
            } else {
                total += actual;
            }
        }
        return total;
    }
}
