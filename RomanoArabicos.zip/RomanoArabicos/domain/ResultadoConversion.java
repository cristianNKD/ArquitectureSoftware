package domain;

public class ResultadoConversion {

    private final boolean exito;
    private final int valor;
    private final String error;

    private ResultadoConversion(boolean exito, int valor, String error) {
        this.exito = exito;
        this.valor = valor;
        this.error = error;
    }

    public static ResultadoConversion ok(int valor) {
        return new ResultadoConversion(true, valor, null);
    }

    public static ResultadoConversion fallo(String mensaje) {
        return new ResultadoConversion(false, 0, mensaje);
    }

    public boolean getExito() {
        return exito;
    }

    public int getValor() {
        return valor;
    }

    public String getError() {
        return error;
    }
}
