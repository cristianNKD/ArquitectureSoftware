import ui.ConversorRomanoUI;
import service.ConversorRomanoService;
import domain.validator.*;
import domain.calculator.CalculadoraRomana;

public class Main {

    public static void main(String[] args) {

        ValidadorCompuesto validador = new ValidadorCompuesto();
        validador.agregarValidador(new ValidadorSimbolosPermitidos());
        validador.agregarValidador(new ValidadorRepeticiones());
        validador.agregarValidador(new ValidadorSustraccion());

        CalculadoraRomana calculadora = new CalculadoraRomana();

        ConversorRomanoService service =
                new ConversorRomanoService(validador, calculadora);

        ConversorRomanoUI ui = new ConversorRomanoUI(service);
        ui.iniciar();
    }
}
