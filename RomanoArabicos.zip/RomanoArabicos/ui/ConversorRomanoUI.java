package ui;

import service.ConversorRomanoService;
import domain.ResultadoConversion;

import java.util.Scanner;

public class ConversorRomanoUI {

    private final ConversorRomanoService service;

    public ConversorRomanoUI(ConversorRomanoService service) {
        this.service = service;
    }

    public void iniciar() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Ingrese número romano: ");
        String entrada = scanner.nextLine()
                .trim()
                .toUpperCase();

        ResultadoConversion resultado = service.convertir(entrada);

        if (resultado.getExito()) {
            mostrarResultado(resultado.getValor());
        } else {
            mostrarError(resultado.getError());
        }
    }

    private void mostrarResultado(int valor) {
        System.out.println("Valor decimal: " + valor);
    }

    private void mostrarError(String mensaje) {
        System.out.println("Error: " + mensaje);
    }
}
