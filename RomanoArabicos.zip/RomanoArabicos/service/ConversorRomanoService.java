package service;

import domain.ResultadoConversion;
import domain.ExcepcionRomanoInvalido;
import domain.validator.ValidadorCompuesto;
import domain.calculator.CalculadoraRomana;

public class ConversorRomanoService {

    private final ValidadorCompuesto validador;
    private final CalculadoraRomana calculadora;

    public ConversorRomanoService(
            ValidadorCompuesto validador,
            CalculadoraRomana calculadora
    ) {
        this.validador = validador;
        this.calculadora = calculadora;
    }

    public ResultadoConversion convertir(String romano) {
        try {
            validador.validar(romano);
            int valor = calculadora.aDecimal(romano);
            return ResultadoConversion.ok(valor);
        } catch (ExcepcionRomanoInvalido e) {
            return ResultadoConversion.fallo(e.getMessage());
        }
    }
}
